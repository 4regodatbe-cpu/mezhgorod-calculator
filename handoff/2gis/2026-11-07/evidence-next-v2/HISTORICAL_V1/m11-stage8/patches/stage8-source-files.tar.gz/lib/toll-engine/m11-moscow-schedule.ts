import aprilSection15Snapshot from "../../data/tolls/m11/2026-04-24-section15-58-category1-no-transponder.json" with { type: "json" };
import novemberSection15Snapshot from "../../data/tolls/m11/2026-11-02-section15-58-category1-no-transponder.json" with { type: "json" };

type Section15Profile = "monThu" | "friday" | "saturday" | "sunday";

function moscowParts(date: Date) {
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Moscow",
    year: "numeric", month: "2-digit", day: "2-digit",
    weekday: "short", hour: "2-digit", hourCycle: "h23",
  });
  const parts = Object.fromEntries(formatter.formatToParts(date).map((part) => [part.type, part.value]));
  return { dateKey: `${parts.year}-${parts.month}-${parts.day}`, weekday: parts.weekday, hour: Number(parts.hour) };
}

function activeSection15Snapshot(date: Date) {
  return date.getTime() >= Date.parse(novemberSection15Snapshot.effectiveFrom)
    ? novemberSection15Snapshot
    : aprilSection15Snapshot;
}

export function section15TariffsAt(date: Date) {
  return activeSection15Snapshot(date).tariffs;
}

function section15Profile(date: Date, snapshot = activeSection15Snapshot(date)): Section15Profile {
  const currentParts = moscowParts(date);
  // The 06:00–01:00 tariff window is named for the day on which it starts.
  // Thus 00:00–00:59 belongs to the previous day's profile.
  const profileDate = currentParts.hour < 1 ? new Date(date.getTime() - 60 * 60 * 1000) : date;
  const parts = moscowParts(profileDate);
  const special = (snapshot.specialDayProfiles2026 as Record<string, Section15Profile>)[parts.dateKey];
  if (special) return special;
  if (parts.weekday === "Fri") return "friday";
  if (parts.weekday === "Sat") return "saturday";
  if (parts.weekday === "Sun") return "sunday";
  return "monThu";
}

export function section15Amount(date: Date) {
  const parts = moscowParts(date);
  const snapshot = activeSection15Snapshot(date);
  const night = parts.hour >= 1 && parts.hour < 6;
  if (night) return { amount: snapshot.tariffs.night0100to0600, profile: "night" };
  const profile = section15Profile(date, snapshot);
  const amount = profile === "monThu"
    ? snapshot.tariffs.monThuDay0600to0100
    : profile === "friday"
      ? snapshot.tariffs.fridayDay0600to0100
      : profile === "saturday"
        ? snapshot.tariffs.saturdayDay0600to0100
        : snapshot.tariffs.sundayDay0600to0100;
  return { amount, profile };
}

export function p58Profile(date: Date) {
  const profile = section15Profile(date, activeSection15Snapshot(date));
  return profile === "monThu" ? "monThu" : "friSun";
}

export function startDate(departureAt?: string) {
  const parsed = departureAt ? new Date(departureAt) : new Date();
  return Number.isNaN(parsed.getTime()) ? new Date() : parsed;
}

