# Stage 8 — official tariff matches and isolated fixes (M-11 correction DONE, local)

Result: [Stage8 official tariff review](STAGE8_RESULT.md); [M-11 correction checkpoint](../../docs/checkpoints/2026-11-06-2gis-stage8-m11-tariff-fix-DONE-LOCAL.md). Current official M-11 Category-I fares from 2026-11-02 01:00 Moscow are versioned in the isolated calculator. M-4 PVP545 remains fail-closed pending current lane→product and tariff-effective-date evidence; the official Avtodor pages returned HTTP403. ZSD's receipt/60-minute linked barrier exception is narrow and not a general re-entry rule. No 2GIS calls in Stage8. Continue only with another independently evidenced operator mapping; CKAD stays no-retry and per-window approvals are unchanged.

# Next steps — 2ГИС diagnostics

## Stage 7 — systemic audit (IN PROGRESS)

Current local result and next five evidence/fix priorities: [STAGE7_FINAL.md](STAGE7_FINAL.md). No more real calls until the runner approval gate has an approved normal reconciliation with the user's series authorization.

- [x] Owner authorized a series of free Routing API diagnostics up to 300 route units; no per-request approval needed within this task. CKAD replay remains prohibited.
- [x] Confirmed branch `codex/2gis-diagnostics`, HEAD `4fe999a08499b22e260db868267c107f6d186dfb`, clean tree at start; Node24.19.
- [x] Attempted read-only Platform Manager count through the connected Opera integration; it timed out. Last owner readback remains 991 with local CKAD ledger entry whose observed debit is 0. Do not call this a live count.
- [x] Inspected managed-cloud status: network policy unrestricted/enforced; no key binding or runtime secret is attached. Process `DGIS_HTTP_API_KEY` is absent.
- [x] Raised the existing tool's task budget guard to 300 while retaining 5 route units/minute and per-window duplicate protection; target tests 13/13 PASS.
- [ ] Continue offline evidence review and candidate ranking across ZSD, M11/M12/CKAD, M4, M1/M3 and regional systems.
- [x] Used the already owner-provided key ephemerally for the first authorized query; no file or report copy. No key remains in the process. PM remains unreadable, so usage is tracked conservatively from last confirmed readback and local ledger.
- [x] M11 PVP18 one request: HTTP200/route OK, 6,369m/514s, payment events2/total_payments entries1. Physical path is not confirmed because selected geometry was only counted, not compared with source witnesses; amount and attribution remain unknown. Expected billing1 Route; actual quota readback unavailable; reserve1 unit.
- [x] ZSD RVP64-exit one request: HTTP200/route OK, 176m/17s, nearest geometry vertex26m from saved source anchor; payment fields absent. This is geometry-consistent with the short corridor, not evidence of a toll booth, paid event, free trip or price. Expected billing1 Route; actual quota readback unavailable; reserve1 unit.
- [x] M-11→Pulkovo access one POST: HTTP200/route OK,741m/48s, 2 route points/1 aggregate entry. Path length739m; nearest geometry vertex266m from gate. Source consistency plausible, exact gate passage and fare attribution unverified; no repeat. Expected1 Route; actual counter unread; working ceiling987.
- [x] Prepared independent reverse Pulkovo gate case `pulkovo-m11-airport-access-reverse`: airport→M-11 via named gate13377945036 on a separate one-way chain, chord0.83km. Dry-run PASS; target tests13/13 PASS.
- [x] Pulkovo→M-11 reverse one POST: HTTP200/route OK,830m/51s,2 route points/1 aggregate entry. Similar to outbound query; geometry remains gate-unverified (nearest vertex240m), price unknown. Expected1 Route; actual counter unread; working ceiling986. No repeat.
- [x] Prepared M-4 PVP545 northbound bypass-side gate crossing using exact one-way OSM sequence via booth5818209495; ~26m. Dry-run PASS, current tariff pair remains unknown.
- [ ] Execute independent source-backed candidates sequentially, never retry an `outcome_unknown` window, and save redacted response summaries/counter deltas. M-4 PVP545 live call is blocked before network by the runner exact-window approval gate despite Stage7 series authorization; no request/debit. The auto-review rejected timestamp refresh as bypass. Do not attempt indirect execution; await an approved normal way to apply series authorization. Continue offline evidence work. Do not repeat CKAD, PVP18, RVP64 or either Pulkovo direction.
- [x] Improved the existing geometry reducer to measure anchor-to-segment distance in memory; regression proves a crossing segment with distant vertices is recognized. No raw WKT retained; 13/13 PASS.
- [ ] Where evidence demonstrates a shared cause, prepare isolated code/test patches and run required focused/full gates. No Production/main/Android, merge or push.
- [ ] Finish only when viable cases are exhausted or a real blocker is reached; update portable bundle and clean tree.

## STAGE 4 — reconcile one attempted call; no retry

- [x] Owner authorized exactly one `ckad-m11-m12` call; pre-call counter 991 and terms were confirmed.
- [x] One attempt made. Fetch timed out before HTTP status or response; ledger status `outcome_unknown`, expected 1 Route, observed quota delta null. No automatic retry.
- [x] Owner reported post-attempt counter 991; observed change from pre-call 991 is 0 units.
- [x] Report timeout and zero observed quota delta; route outcome remains unknown. Stop; do not repeat CKAD or call PVP18/RVP64.

## DONE — подготовка этапа 3

- [x] Текущий branch/HEAD/tree проверены; продолжаем codex/2gis-diagnostics.
- [x] Public 2GIS Routing reference/overview/Pricing проверены 05.11.2026.
- [x] Инструмент защищён отдельным owner approval, endpoint allowlist, write-ahead duplicate reservation, single-run lock и first-result quota-review gate.
- [x] Targeted synthetic checks 11/11 PASS; все три окна DRY_RUN.
- [x] 2GIS API calls 0, quota debit 0; no push/merge/Production/tariff changes.

## Stage 4.1 result — NETWORK_BLOCKED

- [x] Reviewed prior attempt journal and source: exact failure phase was not logged.
- [x] Public-only checks locate the current block before TLS/HTTP: direct DNS EAI_AGAIN; proxy TCP/socket EPERM.
- [x] Opera Browser Connector unavailable; no browser POST path verified. No Routing API calls or retries in stage 4.1.
- [x] Stage ends NETWORK_BLOCKED. Next check requires a separately authorized network-enabled runner or verified browser session; do not repeat the CKAD request.

## Egress permission resolution — no 2GIS call

- [x] Per-command network permission verified against public HTTPS: `with_additional_permissions` with `network.enabled=true`.
- [x] Public HTTPS 200 and verified TLS handshake to `routing.api.2gis.com:443` through configured proxy; no HTTP method/API call, key, or quota use.
- [x] Node fetch requires per-process `NODE_USE_ENV_PROXY=1` to use proxy.
- [x] Opera connector can read tabs but exposes no POST/form/JS control; prefer direct Codex command when separately authorized.
- [ ] No API call authorized by this network diagnostic; prior CKAD outcome remains unknown and must not be repeated.

## Client recovery and request preparation — 2026-11-06

- [x] Verified current HEAD/branch and checked the stated original commit in local Git, GitHub, and available portable archives. Original source/tests unavailable here; do not claim old suite ran.
- [x] Adapted existing runner to documented successful client fields and historical payment-array field names; no new client created.
- [x] Current tests 13/13 PASS; three candidate dry-runs PASS. New M11 PVP18 northbound draft uses alternative=2.
- [x] Runner failure lock narrowed to each allowlisted window; CKAD outcome_unknown remains a permanent no-retry for CKAD and no longer blocks independent PVP18.
- [ ] For the next practical action, obtain a separate owner authorization scoped to M11 PVP18 and exact parameters, then run its single request with fresh key/quota/terms preflight. Do not repeat CKAD.
- [deferred] Original historical client artifact is still unavailable; it is not a gate for the already recovered runner's next separately authorized PVP18 request.

Checkpoint for the runner gate correction: [2026-11-06 window-scoped runner gate](../../docs/checkpoints/2026-11-06-2gis-window-scoped-runner-gate.md). Current tests 13/13 PASS; CKAD and PVP18 DRY_RUN PASS; no API request.
