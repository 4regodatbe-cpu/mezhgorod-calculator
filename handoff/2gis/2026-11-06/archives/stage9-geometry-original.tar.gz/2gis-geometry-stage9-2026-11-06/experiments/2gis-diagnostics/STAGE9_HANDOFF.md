# Technical handoff — geometry diagnosis to primary curator

Date: 2026-11-06. Full evidence: [Stage 9 geometry result](STAGE9_GEOMETRY_RESULT.md).

## Conclusions safe to use

1. **M-4 PVP545:** southern northbound cash branch via one-way way615270691 and booth node5818209495 is distinct from the northern cash branch and neighboring old-road booth. This proves a directed physical branch, not whether it charges 517–544, 544–589, both, or a specific 2026 fare.
2. **M-12:** two saved directed exits (Arzamas road 22Н-0239 and M-7/Cheboksary) are physically connected. Their proposed operator endpoints remain unbound; do not use candidate 2,952/1,239 RUB amounts as proven charges.
3. **CKAD:** physical M-11→M-12 interchange mapping exists in source evidence. The sole API attempt is `outcome_unknown`; never replay it or derive a result from the 991→991 counter reading.
4. **ZSD:** node13020687195 is RVP64 on one-way way351741889. It is a gantry/boundary witness, not an established independent toll plaza or Shkipersky tariff entry. The 2GIS response omitted payment fields; no zero-fare inference.
5. **Stage 8 M-11:** validated compact packet and Stage 8 result remain available locally. It changes tariff/runtime files and belongs to the primary curator's integration review; this geometry work made no further pricing/runtime edits.

## Prohibited inferences

No 2GIS aggregate may be assigned to an operator tariff without an independent road/product crosswalk. No toll-booth proximity, `toll=true`, absent event field, or short route proves the exact product, a free trip, or complete fare. Do not generalize the receipt-bound ZSD no-second-payment exception.

## Open source requirements

- M-4: dated operator rule tying each directed PVP545 lane/branch to product(s), plus current effective tariff and additivity/no-double-charge condition.
- M-12: operator map/coordinate crosswalk from the two physical exit/gantry boundaries to exact charged endpoints.
- ZSD: current official lane/price boundary if a distinct RVP64 price/product is claimed.

No request to change runtime or price tables is made. CKAD replay is forbidden by its outcome-unknown reservation. Existing cases with completed diagnostics must not be repeated.
