"use client";

import { useEffect, useRef, useState } from "react";
import { ThemeToggle } from "@/components/theme-toggle";
import { Calculator, Car, Check, Clipboard, Download, Clock3, HeartHandshake, LoaderCircle, MapPin, MessageSquareText, Percent, Route, Send, Settings2, ShieldCheck, X } from "lucide-react";

type Place = { label: string; position?: { lat: number; lng: number } };
type Suggestion = Place & { id: string; title: string; region: string };
type RouteQuality = { status: "verified" | "single" | "warning"; providers: string[]; distanceSpreadPercent: number | null; message: string };
type TollValidationView = { status: "toll" | "free" | "unknown"; message?: string };
type Trip = { meters: number; seconds: number; quality?: RouteQuality; tollValidation?: TollValidationView };
type TollView = { amount: number | null; weekdayAmount: number | null; weekendAmount: number | null; period: string; segments: string[]; confidence: "matched" | "none"; pricingStatus: "priced" | "free" | "unknown" };
type Leg = {
  from: string;
  to: string;
  fast: Trip & { tolls: TollView };
  free: Trip | null;
  freeCandidate?: Trip | null;
  freeError?: string;
};
type Result = { legs: Leg[] };

const defaults = { standard: 25, comfort: 30, comfortPlus: 35, minivan: 50 };
const tariffNames: Record<keyof typeof defaults, string> = { standard: "Стандарт", comfort: "Комфорт", comfortPlus: "Комфорт+", minivan: "Минивэн" };

function money(value: number) { return `${Math.round(value).toLocaleString("ru-RU")} ₽`; }
function distance(meters: number) { return `${(meters / 1000).toLocaleString("ru-RU", { maximumFractionDigits: 1 })} км`; }
function duration(seconds: number) { const minutes = Math.round(seconds / 60); return `${Math.floor(minutes / 60)} ч ${minutes % 60} мин`; }
function pickOptimal(fast: Trip, free: Trip | null) {
  if (!free) return fast;
  return free.meters < fast.meters || (free.meters === fast.meters && free.seconds < fast.seconds) ? free : fast;
}

function AddressField({ label, value, onChange, placeholder }: { label: string; value: Place; onChange: (place: Place) => void; placeholder: string }) {
  const [items, setItems] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (value.position || value.label.trim().length < 3) return;
    const timer = setTimeout(async () => {
      try { const response = await fetch(`/api/suggest?q=${encodeURIComponent(value.label)}`); const data = await response.json(); setItems(data.items ?? []); setOpen(true); } catch { setItems([]); }
    }, 350);
    return () => clearTimeout(timer);
  }, [value]);
  return <label className="relative block min-w-0">
    <span className="mb-1.5 block text-xs font-bold uppercase tracking-[.14em] text-slate-400">{label}</span>
    <div className="relative"><MapPin className="pointer-events-none absolute left-3 top-3 h-5 w-5 text-blue-400"/><input ref={inputRef} className="h-12 w-full rounded-xl border border-slate-700 bg-slate-950/75 pl-10 pr-12 text-[16px] text-white outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20" value={value.label} placeholder={placeholder} autoComplete="off" onChange={(e) => { onChange({ label: e.target.value }); setItems([]); setOpen(true); }} onFocus={() => setOpen(true)}/>{value.label && <button type="button" aria-label={`Очистить поле «${label}»`} onClick={() => { onChange({ label: "" }); setItems([]); setOpen(false); requestAnimationFrame(() => inputRef.current?.focus()); }} className="absolute right-1 top-1 grid h-10 w-10 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-800 hover:text-white"><X className="h-4.5 w-4.5"/></button>}</div>
    {open && items.length > 0 && <div className="absolute z-30 mt-2 max-h-64 w-full overflow-auto rounded-xl border border-slate-700 bg-slate-900 p-1 shadow-2xl">{items.map((item) => <button type="button" key={item.id} className="block w-full rounded-lg px-3 py-2.5 text-left hover:bg-slate-800" onClick={() => { onChange({ label: item.label, position: item.position }); setOpen(false); }}><strong className="block text-sm text-white">{item.title}</strong><span className="block truncate text-xs text-slate-400">{item.label}</span></button>)}</div>}
  </label>;
}

function TariffInputs({ rates, setRates }: { rates: typeof defaults; setRates: (rates: typeof defaults) => void }) {
  return <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{(Object.keys(rates) as Array<keyof typeof rates>).map((key) => <label key={key} className="rounded-xl border border-slate-700 bg-slate-950/55 p-2.5"><span className="block text-xs font-semibold text-slate-300">{tariffNames[key]}</span><span className="mt-1 flex items-center gap-1"><input aria-label={`Цена ${tariffNames[key]}`} type="number" min="1" max="10000" value={rates[key]} onChange={(e) => setRates({ ...rates, [key]: Math.max(1, Number(e.target.value) || 1) })} className="w-full bg-transparent text-lg font-black text-white outline-none"/><span className="text-xs text-slate-500">₽/км</span></span></label>)}</div>;
}

function PriceRows({ meters, rates, multiplier }: { meters: number; rates: typeof defaults; multiplier: number }) {
  return <div className="mt-3 grid grid-cols-2 gap-2">{(Object.keys(rates) as Array<keyof typeof rates>).map((key) => <div key={key} className="rounded-xl bg-slate-950/60 px-3 py-2"><span className="block text-xs text-slate-400">{tariffNames[key]}</span><strong className="text-base text-white">{money(meters / 1000 * rates[key] * multiplier)}</strong></div>)}</div>;
}

function QualityNote({ quality }: { quality?: RouteQuality }) {
  if (!quality) return null;
  const warning = quality.status === "warning";
  const single = quality.status === "single";
  return <p className={`mt-2 flex items-start gap-1.5 text-xs leading-relaxed ${warning ? "text-amber-300" : single ? "text-slate-400" : "text-emerald-300"}`}>
    <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0"/>
    <span>{quality.message}</span>
  </p>;
}

function RouteCard({ title, accent, trip, rates, multiplier, toll, manualToll, onManualToll, onCopy, copied }: { title: string; accent: "blue" | "emerald"; trip: Trip; rates: typeof defaults; multiplier: number; toll?: TollView; manualToll?: string; onManualToll?: (value: string) => void; onCopy: () => void; copied: boolean }) {
  const tollAmount = manualToll === "" || manualToll == null ? toll?.amount ?? 0 : Number(manualToll) || 0;
  return <article className={`rounded-2xl border bg-slate-900/80 p-4 shadow-xl ${accent === "blue" ? "border-blue-500/45" : "border-emerald-500/40"}`}>
    <div className="flex items-center justify-between gap-3"><h3 className="font-black text-white">{title}</h3><span className={`rounded-full px-2.5 py-1 text-xs font-bold ${accent === "blue" ? "bg-blue-500/15 text-blue-300" : "bg-emerald-500/15 text-emerald-300"}`}>{accent === "blue" ? "Быстрее" : "Без оплаты дорог"}</span></div>
    <div className="mt-3 flex gap-5 text-sm"><span className="flex items-center gap-1.5 text-slate-300"><Route className="h-4 w-4"/>{distance(trip.meters)}</span><span className="flex items-center gap-1.5 text-slate-300"><Clock3 className="h-4 w-4"/>{duration(trip.seconds)}</span></div>
    <QualityNote quality={trip.quality}/>
    <PriceRows meters={trip.meters} rates={rates} multiplier={multiplier}/>
    {toll && <div className="mt-3 rounded-xl border border-amber-500/25 bg-amber-500/10 p-3 text-sm"><div className="flex items-center justify-between gap-2"><span className="text-amber-900 dark:text-amber-100">Платная дорога</span>{manualToll !== "" ? <strong className="text-amber-700 dark:text-amber-300">+ {money(tollAmount)}</strong> : toll.weekdayAmount !== toll.weekendAmount ? <div className="text-right text-xs"><strong className="block text-amber-700 dark:text-amber-300">Пн–Чт: + {money(toll.weekdayAmount ?? 0)}</strong><strong className="mt-0.5 block text-amber-700 dark:text-amber-300">Пт–Вс: + {money(toll.weekendAmount ?? 0)}</strong></div> : <strong className="text-amber-700 dark:text-amber-300">{tollAmount > 0 ? `+ ${money(tollAmount)}` : "Стоимость не определена"}</strong>}</div><p className="mt-1 text-xs text-amber-900/70 dark:text-amber-100/65">{tollAmount > 0 ? "Ориентировочно, легковой автомобиль без транспондера. В стоимость поездки не включено." : "Встроенный справочник пока не содержит этот участок. Укажите известную стоимость вручную."}</p><label className="mt-2 flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">Уточнить вручную:<input type="number" min="0" value={manualToll} placeholder={(toll.amount ?? 0) > 0 ? String(toll.amount) : "Сумма"} onChange={(e) => onManualToll?.(e.target.value)} className="h-8 w-24 rounded-lg border border-slate-400 bg-white px-2 text-slate-950 outline-none dark:border-slate-600 dark:bg-slate-950 dark:text-white"/> ₽</label></div>}
    <button type="button" onClick={onCopy} className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-950/70 text-sm font-bold text-white transition hover:border-blue-500 hover:bg-slate-900">{copied ? <><Check className="h-4 w-4"/>Скопировано</> : <><Clipboard className="h-4 w-4"/>Скопировать результат</>}</button>
  </article>;
}

function UnverifiedRouteCard({ trip, rates, multiplier, onCopy, copied }: { trip: Trip; rates: typeof defaults; multiplier: number; onCopy: () => void; copied: boolean }) {
  return <article className="rounded-2xl border border-amber-500/40 bg-slate-900/80 p-4 shadow-xl">
    <div className="flex items-center justify-between gap-3"><h3 className="font-black text-white">Альтернативный маршрут</h3><span className="rounded-full bg-amber-500/15 px-2.5 py-1 text-xs font-bold text-amber-300">Платность не подтверждена</span></div>
    <div className="mt-3 flex gap-5 text-sm"><span className="flex items-center gap-1.5 text-slate-300"><Route className="h-4 w-4"/>{distance(trip.meters)}</span><span className="flex items-center gap-1.5 text-slate-300"><Clock3 className="h-4 w-4"/>{duration(trip.seconds)}</span></div>
    <p className="mt-2 flex items-start gap-1.5 text-xs leading-relaxed text-amber-300"><ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0"/><span>{trip.tollValidation?.message ?? trip.quality?.message ?? "Независимая проверка не завершена. Маршрут нельзя считать подтверждённо бесплатным."}</span></p>
    <PriceRows meters={trip.meters} rates={rates} multiplier={multiplier}/>
    <p className="mt-2 text-xs text-slate-500">Расчёт тарифа показан только по расстоянию. Возможная стоимость платных дорог не включена и требует отдельной проверки.</p>
    <button type="button" onClick={onCopy} className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-amber-500/35 bg-slate-950/70 text-sm font-bold text-white transition hover:bg-slate-900">{copied ? <><Check className="h-4 w-4"/>Скопировано</> : <><Clipboard className="h-4 w-4"/>Скопировать с предупреждением</>}</button>
  </article>;
}

function FeedbackForm() {
  const [category, setCategory] = useState("Улучшение калькулятора");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  async function submit(event: React.FormEvent) { event.preventDefault(); if (message.trim().length < 10) { setStatus("error"); return; } setStatus("sending"); try { const response = await fetch("/api/collect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "feedback", category: `[2.0] ${category}`, message, website: "" }) }); if (!response.ok) throw new Error(); setMessage(""); setStatus("sent"); } catch { setStatus("error"); } }
  return <section className="rounded-2xl border border-slate-700 bg-slate-900/80 p-4"><MessageSquareText className="h-5 w-5 text-blue-400"/><h2 className="mt-3 text-lg font-black text-white">Предложить улучшение</h2><p className="mt-1 text-sm text-slate-400">Напишите, чего не хватает калькулятору.</p><form onSubmit={submit} className="mt-4 space-y-3"><select value={category} onChange={(e) => setCategory(e.target.value)} className="h-11 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 text-sm text-white"><option>Улучшение калькулятора</option><option>Новая функция</option><option>Сообщить об ошибке</option><option>Другое</option></select><textarea value={message} onChange={(e) => { setMessage(e.target.value); setStatus("idle"); }} minLength={10} maxLength={1000} required rows={4} placeholder="Ваше предложение…" className="w-full resize-y rounded-xl border border-slate-700 bg-slate-950 p-3 text-[16px] text-white outline-none focus:border-blue-500"/>{status === "sent" && <p className="text-sm font-bold text-emerald-400">Спасибо! Предложение сохранено.</p>}{status === "error" && <p className="text-sm font-bold text-red-400">Введите не менее 10 символов или попробуйте позже.</p>}<button disabled={status === "sending"} className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-blue-600 text-sm font-bold text-white"><Send className="h-4 w-4"/>{status === "sending" ? "Отправляем…" : "Отправить идею"}</button></form></section>;
}

function DonationCard() {
  return <section className="rounded-2xl border border-emerald-500/30 bg-emerald-950/35 p-4"><HeartHandshake className="h-5 w-5 text-emerald-400"/><h2 className="mt-3 text-lg font-black text-white">Сбор на API Яндекс Карт</h2><p className="mt-1 text-sm leading-relaxed text-slate-300">Хотим получать маршруты напрямую от Яндекса — это сделает расстояния и расчёт платных дорог максимально точными. Сейчас бесплатные источники требуют ручных проверок.</p><a href="https://t.tb.ru/pm_short/4YCKLToUeM6" target="_blank" rel="noopener noreferrer" className="mt-4 flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 text-sm font-black text-emerald-950 transition hover:bg-emerald-400"><HeartHandshake className="h-4 w-4"/>Поддержать подключение</a><p className="mt-2 text-center text-xs text-slate-500">Перевод откроется на защищённой странице Т‑Банка.</p></section>;
}

function RouteUnavailable({ message }: { message?: string }) {
  return <article className="rounded-2xl border border-slate-700 bg-slate-900/80 p-4 shadow-xl">
    <div className="flex items-center justify-between gap-3"><h3 className="font-black text-white">Маршрут без платных дорог</h3><span className="rounded-full bg-amber-500/15 px-2.5 py-1 text-xs font-bold text-amber-300">Не подтверждён</span></div>
    <p className="mt-3 text-sm leading-relaxed text-slate-300">{message ?? "Маршрут временно недоступен. Повторите расчёт позже."}</p>
    <p className="mt-2 text-xs text-slate-500">Расчёт по быстрому маршруту выше остаётся действительным.</p>
  </article>;
}

function DualUnverifiedNotice({ result }: { result: Result }) {
  const candidates = result.legs.map((leg, index) => ({ leg, index, candidate: leg.freeCandidate })).filter((item) => Boolean(item.candidate));
  if (candidates.length === 0) return null;
  return <article className="rounded-2xl border border-amber-500/35 bg-amber-500/5 p-4">
    <div className="flex items-center justify-between gap-3"><h3 className="font-black text-white">Непроверенные альтернативы</h3><span className="rounded-full bg-amber-500/15 px-2.5 py-1 text-xs font-bold text-amber-300">Не входят в итог</span></div>
    <p className="mt-2 text-sm text-slate-300">По этим участкам маршрутизатор предложил обход, но независимая проверка не доказала отсутствие платных дорог.</p>
    <div className="mt-3 space-y-2">{candidates.map(({ leg, index, candidate }) => <div key={index} className="rounded-xl bg-slate-950/55 p-3"><p className="text-xs text-slate-400">Участок {index + 1}: {leg.from} → {leg.to}</p><p className="mt-1 text-sm text-white">{distance(candidate!.meters)} · {duration(candidate!.seconds)}</p><p className="mt-1 text-xs text-amber-300">{candidate!.tollValidation?.message ?? "Платность не подтверждена"}</p></div>)}</div>
  </article>;
}

export default function V2Page() {
  const [mode, setMode] = useState<"standard" | "dual">("standard");
  const [from, setFrom] = useState<Place>({ label: "" }); const [via, setVia] = useState<Place>({ label: "" }); const [to, setTo] = useState<Place>({ label: "" });
  const [rates, setRates] = useState(() => { if (typeof window === "undefined") return defaults; try { const saved = localStorage.getItem("mezhgorod-v2-rates"); return saved ? { ...defaults, ...JSON.parse(saved) } : defaults; } catch { return defaults; } }); const [rate1, setRate1] = useState(25); const [rate2, setRate2] = useState(35);
  const [urgent, setUrgent] = useState(false); const [urgentPercent, setUrgentPercent] = useState(20);
  const [result, setResult] = useState<Result | null>(null); const [error, setError] = useState(""); const [loading, setLoading] = useState(false); const [manualToll, setManualToll] = useState(""); const [isAndroidApp, setIsAndroidApp] = useState(false); const [copiedKey, setCopiedKey] = useState("");
  useEffect(() => { localStorage.setItem("mezhgorod-v2-rates", JSON.stringify(rates)); }, [rates]);
  useEffect(() => { setIsAndroidApp(navigator.userAgent.includes("MezhgorodAndroidV2")); }, []);
  useEffect(() => { let visitorId = localStorage.getItem("mezhgorod-anonymous-visitor-id"); if (!visitorId) { visitorId = crypto.randomUUID(); localStorage.setItem("mezhgorod-anonymous-visitor-id", visitorId); } if (sessionStorage.getItem("mezhgorod-visit-sent")) return; void fetch("/api/collect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "visit", visitorId, version: "2.0" }) }).then((response) => { if (response.ok) sessionStorage.setItem("mezhgorod-visit-sent", "1"); }).catch(() => undefined); }, []);
  const multiplier = urgent ? 1 + Math.max(0, urgentPercent) / 100 : 1;
  const standardLeg = result?.legs[0];
  const standardHasTolls = standardLeg ? standardLeg.fast.tolls.pricingStatus !== "free" : false;
  const standardOptimal = standardLeg ? pickOptimal(standardLeg.fast, standardLeg.free) : null;
  const dualHasTolls = result?.legs.some((leg) => leg.fast.tolls.pricingStatus !== "free") ?? false;
  const dualVariants: Array<"fast" | "free" | "optimal"> = dualHasTolls ? ["fast", "free"] : ["optimal"];
  function recordRoutes(data: Result) { data.legs.forEach((leg) => { const variants = leg.fast.tolls.pricingStatus !== "free" ? [{ type: leg.fast.tolls.pricingStatus === "unknown" ? "Быстрый, цена дорог ?" : "Платный", trip: leg.fast, tolls: leg.fast.tolls }, ...(leg.free ? [{ type: "Бесплатный", trip: leg.free, tolls: null }] : [])] : [{ type: "Оптимальный", trip: pickOptimal(leg.fast, leg.free), tolls: null }]; variants.forEach(({ type, trip, tolls }) => { const totals = mode === "standard" ? Object.fromEntries((Object.keys(rates) as Array<keyof typeof rates>).map((key) => [key, Math.round(trip.meters / 1000 * rates[key] * multiplier)])) : { standard: Math.round(trip.meters / 1000 * (leg === data.legs[0] ? rate1 : rate2) * multiplier), comfort: 0, comfortPlus: 0, minivan: 0 }; void fetch("/api/collect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "route_v2", fromRegion: leg.from, toRegion: leg.to, distanceKm: Math.round(trip.meters / 100) / 10, durationMin: Math.round(trip.seconds / 60), routeType: type, totals, tollWeekday: tolls ? tolls.weekdayAmount : 0, tollWeekend: tolls ? tolls.weekendAmount : 0, tollPricingStatus: tolls?.pricingStatus ?? "free" }) }).catch(() => undefined); }); }); }
  async function calculate() { setError(""); setResult(null); setLoading(true); setManualToll(""); setCopiedKey(""); try { const response = await fetch("/api/v2/calculate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode, from, via, to, departureAt: new Date().toISOString() }) }); const data = await response.json(); if (!response.ok) throw new Error(data.error); setResult(data); recordRoutes(data); } catch (e) { setError(e instanceof Error ? e.message : "Не удалось выполнить расчёт"); } finally { setLoading(false); } }
  async function copyStandard(key: string, title: string, leg: Leg, trip: Trip, toll?: TollView, warning?: string) { const lines = [`Калькулятор межгород`, `${title}: ${leg.from} → ${leg.to}`, `${distance(trip.meters)} · ${duration(trip.seconds)}`, ...((Object.keys(defaults) as Array<keyof typeof defaults>).map((rate) => `${tariffNames[rate]}: ${money(trip.meters / 1000 * rates[rate] * multiplier)}`))]; if (toll) { if (toll.pricingStatus === "unknown") lines.push("Платная дорога: стоимость не определена"); else if (toll.weekdayAmount !== toll.weekendAmount) lines.push(`Платная дорога: Пн–Чт ${money(toll.weekdayAmount ?? 0)}, Пт–Вс ${money(toll.weekendAmount ?? 0)}`); else if (toll.pricingStatus === "priced") lines.push(`Платная дорога: ${money(toll.amount ?? 0)}`); } if (warning) lines.push(`Важно: ${warning}`); await navigator.clipboard.writeText(lines.join("\n")); setCopiedKey(key); setTimeout(() => setCopiedKey(""), 1800); }
  async function copyDual(key: string, title: string, trips: Trip[], total: number, tollWeekday: number, tollWeekend: number, tollUnknown: boolean) { const lines = [`Калькулятор межгород`, title, ...result!.legs.map((leg, index) => `Участок ${index + 1}: ${leg.from} → ${leg.to} · ${distance(trips[index].meters)} · ${duration(trips[index].seconds)} · ${money(trips[index].meters / 1000 * (index === 0 ? rate1 : rate2) * multiplier)}`), `Итого: ${money(total)}`]; if (tollUnknown) lines.push("Платная дорога: стоимость не определена"); else if (tollWeekday > 0) lines.push(tollWeekday !== tollWeekend ? `Платная дорога: Пн–Чт ${money(tollWeekday)}, Пт–Вс ${money(tollWeekend)}` : `Платная дорога: ${money(tollWeekday)}`); await navigator.clipboard.writeText(lines.join("\n")); setCopiedKey(key); setTimeout(() => setCopiedKey(""), 1800); }

  return <main className="calculator-modern min-h-screen bg-slate-100 text-slate-950 dark:bg-[#070b14] dark:text-slate-100">
    <div className="mx-auto max-w-5xl px-3 py-4 sm:px-6 sm:py-8">
      <header className="mb-4 flex items-center justify-between gap-2"><div className="flex min-w-0 items-center gap-2"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-700 shadow-lg shadow-blue-900/30"><Car className="h-5 w-5"/></div><h1 className="text-base font-black leading-tight sm:text-2xl">Калькулятор межгород</h1></div><div className="flex shrink-0 items-center gap-1.5"><ThemeToggle />{!isAndroidApp && <a href="https://github.com/4regodatbe-cpu/mezhgorod-calculator/releases/download/android-latest/Mezhgorod-Calc-2.apk" download="Mezhgorod-Calc-2.apk" aria-label="Скачать для Android" className="flex h-10 items-center gap-1 rounded-xl bg-blue-600 px-2 text-[11px] font-bold text-white shadow-md transition hover:bg-blue-700 sm:px-3 sm:text-xs"><Download className="h-4 w-4 shrink-0"/>Скачать для Android</a>}</div></header>
      <section className="rounded-[1.5rem] border border-slate-800 bg-slate-900/70 p-3 shadow-2xl backdrop-blur sm:p-5">
        <div className="mb-4 grid grid-cols-2 rounded-xl bg-slate-950 p-1"><button onClick={() => { setMode("standard"); setResult(null); }} className={`min-h-11 rounded-lg px-3 text-sm font-bold transition ${mode === "standard" ? "bg-blue-600 text-white" : "text-slate-400"}`}>Обычный расчёт</button><button onClick={() => { setMode("dual"); setResult(null); }} className={`min-h-11 rounded-lg px-3 text-sm font-bold transition ${mode === "dual" ? "bg-blue-600 text-white" : "text-slate-400"}`}>Двойная тарификация</button></div>
        <div className={`grid gap-3 ${mode === "dual" ? "lg:grid-cols-3" : "sm:grid-cols-2"}`}><AddressField label="Точка A" value={from} onChange={setFrom} placeholder="Откуда"/>{mode === "dual" && <AddressField label="Промежуточная точка" value={via} onChange={setVia} placeholder="Граница тарифа"/>}<AddressField label="Точка B" value={to} onChange={setTo} placeholder="Куда"/></div>
        <div className="mt-4 border-t border-slate-800 pt-4"><div className="mb-2 flex items-center gap-2 text-sm font-bold"><Settings2 className="h-4 w-4 text-blue-400"/>{mode === "standard" ? "Тарифы" : "Тарифы участков"}</div>{mode === "standard" ? <TariffInputs rates={rates} setRates={setRates}/> : <div className="grid grid-cols-2 gap-2"><label className="rounded-xl border border-slate-700 bg-slate-950/55 p-2.5"><span className="text-xs text-slate-400">A → промежуточная</span><span className="mt-1 flex"><input type="number" value={rate1} onChange={(e) => setRate1(Number(e.target.value) || 1)} className="w-full bg-transparent text-lg font-black outline-none"/><small>₽/км</small></span></label><label className="rounded-xl border border-slate-700 bg-slate-950/55 p-2.5"><span className="text-xs text-slate-400">Промежуточная → B</span><span className="mt-1 flex"><input type="number" value={rate2} onChange={(e) => setRate2(Number(e.target.value) || 1)} className="w-full bg-transparent text-lg font-black outline-none"/><small>₽/км</small></span></label></div>}</div>
        <div className="mt-3 flex flex-wrap items-center gap-3 rounded-xl bg-slate-950/65 p-3"><button type="button" role="switch" aria-checked={urgent} onClick={() => setUrgent(!urgent)} className={`relative h-7 w-12 rounded-full transition ${urgent ? "bg-orange-500" : "bg-slate-700"}`}><span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition ${urgent ? "left-6" : "left-1"}`}/></button><span className="text-sm font-bold">Срочная поездка</span>{urgent && <label className="ml-auto flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-900 px-2"><Percent className="h-4 w-4 text-orange-400"/><input aria-label="Наценка за срочность" type="number" min="0" max="500" value={urgentPercent} onChange={(e) => setUrgentPercent(Number(e.target.value) || 0)} className="h-9 w-14 bg-transparent text-right font-bold outline-none"/><span className="text-sm text-slate-400">%</span></label>}</div>
        <button onClick={calculate} disabled={loading} className="mt-3 flex min-h-13 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 px-5 font-black text-white shadow-lg shadow-blue-950/30 transition hover:brightness-110 disabled:opacity-60">{loading ? <LoaderCircle className="h-5 w-5 animate-spin"/> : <Calculator className="h-5 w-5"/>}{loading ? "Строим два маршрута…" : "Рассчитать поездку"}</button>
        {error && <p role="alert" className="mt-3 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200">{error}</p>}
      </section>

      {result && mode === "standard" && standardLeg && standardOptimal && <section className={`mt-4 grid gap-3 ${standardHasTolls ? "md:grid-cols-2" : "grid-cols-1"}`}>{standardHasTolls ? <><RouteCard title={standardLeg.fast.tolls.pricingStatus === "unknown" ? "Быстрый маршрут" : "По платной дороге"} accent="blue" trip={standardLeg.fast} rates={rates} multiplier={multiplier} toll={standardLeg.fast.tolls} manualToll={manualToll} onManualToll={setManualToll} onCopy={() => copyStandard("standard-fast", standardLeg.fast.tolls.pricingStatus === "unknown" ? "Быстрый маршрут" : "По платной дороге", standardLeg, standardLeg.fast, standardLeg.fast.tolls)} copied={copiedKey === "standard-fast"}/>{standardLeg.free ? <RouteCard title="Без платных дорог" accent="emerald" trip={standardLeg.free} rates={rates} multiplier={multiplier} onCopy={() => copyStandard("standard-free", "Без платных дорог", standardLeg, standardLeg.free!)} copied={copiedKey === "standard-free"}/> : standardLeg.freeCandidate ? <UnverifiedRouteCard trip={standardLeg.freeCandidate} rates={rates} multiplier={multiplier} onCopy={() => copyStandard("standard-candidate", "Альтернативный маршрут", standardLeg, standardLeg.freeCandidate!, undefined, "Платность маршрута не подтверждена. Возможная стоимость платных дорог не включена.")} copied={copiedKey === "standard-candidate"}/> : <RouteUnavailable message={standardLeg.freeError}/>}</> : <RouteCard title="Оптимальный маршрут" accent="blue" trip={standardOptimal} rates={rates} multiplier={multiplier} onCopy={() => copyStandard("standard-optimal", "Оптимальный маршрут", standardLeg, standardOptimal)} copied={copiedKey === "standard-optimal"}/>}</section>}
      {result && mode === "dual" && <section className="mt-4 space-y-3"><div className={`grid gap-3 ${dualHasTolls ? "md:grid-cols-2" : "grid-cols-1"}`}>{dualVariants.map((variant) => { const fast = variant === "fast"; const optimal = variant === "optimal"; const available = fast || optimal || result.legs.every((leg) => leg.free); if (!available) return <RouteUnavailable key={variant} message={result.legs.find((leg) => !leg.free)?.freeError}/>; const trips = result.legs.map((leg) => optimal ? pickOptimal(leg.fast, leg.free) : fast ? leg.fast : leg.free!); const total = trips.reduce((sum, trip, index) => sum + trip.meters / 1000 * (index === 0 ? rate1 : rate2), 0) * multiplier; const tollUnknown = fast && result.legs.some((leg) => leg.fast.tolls.pricingStatus === "unknown"); const tollWeekday = result.legs.reduce((sum, leg) => sum + (fast ? (leg.fast.tolls.weekdayAmount ?? 0) : 0), 0); const tollWeekend = result.legs.reduce((sum, leg) => sum + (fast ? (leg.fast.tolls.weekendAmount ?? 0) : 0), 0); const title = optimal ? "Оптимальный маршрут" : fast ? "По платной дороге" : "Без платных дорог"; return <article key={variant} className={`rounded-2xl border bg-slate-900/80 p-4 ${fast || optimal ? "border-blue-500/45" : "border-emerald-500/40"}`}><div className="flex items-center justify-between"><h3 className="font-black">{title}</h3><Route className={`h-5 w-5 ${fast || optimal ? "text-blue-400" : "text-emerald-400"}`}/></div>{result.legs.map((leg, index) => { const trip = trips[index]; const rate = index === 0 ? rate1 : rate2; return <div key={index} className="mt-3 rounded-xl bg-slate-950/60 p-3"><p className="truncate text-xs text-slate-400">Участок {index + 1}: {leg.from} → {leg.to}</p><div className="mt-1 flex items-end justify-between gap-3"><span className="text-sm">{distance(trip.meters)} · {duration(trip.seconds)}</span><strong>{money(trip.meters / 1000 * rate * multiplier)}</strong></div><QualityNote quality={trip.quality}/></div>})}<div className="mt-3 flex items-center justify-between border-t border-slate-700 pt-3"><span className="font-bold">Итого</span><strong className="text-xl text-blue-300">{money(total)}</strong></div>{fast && tollUnknown ? <div className="mt-2 text-right text-xs font-semibold text-amber-700 dark:text-amber-300">Стоимость платных дорог не определена</div> : fast && tollWeekday > 0 ? <div className="mt-2 text-right text-xs text-amber-700 dark:text-amber-300">{tollWeekday !== tollWeekend ? <><p>Пн–Чт: + {money(tollWeekday)} платные дороги</p><p>Пт–Вс: + {money(tollWeekend)} платные дороги</p></> : <p>+ {money(tollWeekday)} платные дороги, ориентировочно</p>}</div> : null}<button type="button" onClick={() => copyDual(`dual-${variant}`, title, trips, total, tollWeekday, tollWeekend, tollUnknown)} className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-950/70 text-sm font-bold text-white">{copiedKey === `dual-${variant}` ? <><Check className="h-4 w-4"/>Скопировано</> : <><Clipboard className="h-4 w-4"/>Скопировать результат</>}</button></article> })}</div><DualUnverifiedNotice result={result}/></section>}
      <div className="mt-4 grid gap-3 md:grid-cols-2"><FeedbackForm/><DonationCard/></div>
      <footer className="mx-auto mt-6 max-w-3xl pb-5 text-center text-xs leading-relaxed text-slate-500"><p className="flex items-center justify-center gap-1.5"><ShieldCheck className="h-4 w-4"/>Расчёт справочный. Фактический маршрут и тарифы операторов дорог могут измениться.</p></footer>
    </div>
  </main>;
}
